let video;
let handpose;
let predictions = [];

function setup() {
  createCanvas(640, 480);
  video = createCapture(VIDEO);
  video.size(width, height);

  handpose = ml5.handpose(video, modelReady);
  handpose.on("predict", results => {
    predictions = results;
  });
}

function modelReady() {
  console.log("Model ready!");
}

function draw() {
  background(0);
  drawKeypoints();
}

function drawKeypoints() {
  for (let i = 0; i < predictions.length; i++) {
    let hand = predictions[i];
    for (let fingerIndex = 0; fingerIndex < hand.annotations.thumb.length; fingerIndex++) {
      let finger = hand.annotations.thumb[fingerIndex];
      fill(255, 0, 0);
      noStroke();
      ellipse(finger[0], finger[1], 10, 10);
    }

    for (let fingerIndex = 0; fingerIndex < hand.annotations.indexFinger.length; fingerIndex++) {
      let finger = hand.annotations.indexFinger[fingerIndex];
      fill(0, 255, 0);
      noStroke();
      ellipse(finger[0], finger[1], 10, 10);
    }

    for (let fingerIndex = 0; fingerIndex < hand.annotations.middleFinger.length; fingerIndex++) {
      let finger = hand.annotations.middleFinger[fingerIndex];
      fill(0, 0, 255);
      noStroke();
      ellipse(finger[0], finger[1], 10, 10);
    }

    for (let fingerIndex = 0; fingerIndex < hand.annotations.ringFinger.length; fingerIndex++) {
      let finger = hand.annotations.ringFinger[fingerIndex];
      fill(255, 255, 0);
      noStroke();
      ellipse(finger[0], finger[1], 10, 10);
    }

    for (let fingerIndex = 0; fingerIndex < hand.annotations.pinky.length; fingerIndex++) {
      let finger = hand.annotations.pinky[fingerIndex];
      fill(255, 0, 255);
      noStroke();
      ellipse(finger[0], finger[1], 10, 10);
    }
  }
}
